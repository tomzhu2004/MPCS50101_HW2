# @Date:   2017-01-11T00:38:50-06:00
# @Last modified time: 2017-01-11T00:56:25-06:00



print "I will now count my chickens:"
# Just a statement
print "Hens", 25 + 30 / 6.0
print "Roosters", 100 -25 * 3 % 4
# Math operation follows PEMDAS. Bottom is 100 minuss 4% of 75
print "Now I will count the eggs:"
# Another declaration
print 3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6

print "Is it true that 3 + 2 < 5 - 7?"

print 3 + 2 < 5 - 7

print "What is 3 + 2?", 3 + 2
print "What is 5 - 7?", 5 - 7

print "Oh, that's why it's False."

print "How about some more."
# Inequalities result in True/False statements
print "Is it greater?", 5 > -2
print "Is it greater or equal?", 5 >= -2
print "Is it less or equal?", 5 <= -2
