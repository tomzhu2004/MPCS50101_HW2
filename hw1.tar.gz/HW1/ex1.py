# @Date:   2017-01-10T23:14:23-06:00
# @Last modified time: 2017-01-11T00:16:13-06:00



print "Hello World!"
print "Hello Again"
print "I like typing this."
print "This is fun."
print 'Yay! Printing.'
print "I'd much rather you 'not'."
print 'I "said" do not toucch this.'
