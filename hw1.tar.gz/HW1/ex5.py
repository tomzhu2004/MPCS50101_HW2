# @Date:   2017-01-11T01:36:53-06:00
# @Last modified time: 2017-01-11T01:47:25-06:00



my_name = 'Yuguang Zhu'
my_age = 28 # 100% True
my_height = 70 # inches, tall, not long
my_weight = 170 # pounds
my_eyes = 'Brown'
my_teeth = 'White'
my_hair = 'Jet Black'

print "Let's talk about %s." % my_name
print "He's %d inches tall." % my_height
print "He's %d pounds heavy." % my_weight
print "Actually he needs to lose some weight."
print "He's got %s eyes and %s hair." % (my_eyes, my_hair)
print "His teeth are usually %s but that might change if he starts to smoke." % my_teeth


#this line is tricky, try to get it exactly right
print "If I add %d, %d, and %d I get %d." % ( my_age, my_height, my_weight, my_age + my_height + my_weight)
